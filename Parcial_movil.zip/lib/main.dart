import 'package:flutter/material.dart';
import 'package:flutterapp/parcial_movilapp/generatedmainpagewidget/GeneratedMainpageWidget.dart';
import 'package:flutterapp/parcial_movilapp/generatedcitaswidget/GeneratedCitasWidget.dart';
import 'package:flutterapp/parcial_movilapp/generatedbarberoswidget1/GeneratedBarberosWidget1.dart';
import 'package:flutterapp/parcial_movilapp/generatedservicioswidget/GeneratedServiciosWidget.dart';
import 'package:flutterapp/parcial_movilapp/generatedprecioswidget1/GeneratedPreciosWidget1.dart';

void main() {
  runApp(Parcial_movilApp());
}

class Parcial_movilApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedMainpageWidget',
      routes: {
        '/GeneratedMainpageWidget': (context) => GeneratedMainpageWidget(),
        '/GeneratedCitasWidget': (context) => GeneratedCitasWidget(),
        '/GeneratedBarberosWidget1': (context) => GeneratedBarberosWidget1(),
        '/GeneratedServiciosWidget': (context) => GeneratedServiciosWidget(),
        '/GeneratedPreciosWidget1': (context) => GeneratedPreciosWidget1(),
      },
    );
  }
}
